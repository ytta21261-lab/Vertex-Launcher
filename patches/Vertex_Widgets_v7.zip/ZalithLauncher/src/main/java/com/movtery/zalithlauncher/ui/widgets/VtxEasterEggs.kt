/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.widgets

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.ui.theme.Vtx
import com.movtery.zalithlauncher.ui.theme.VtxDiamond
import com.movtery.zalithlauncher.ui.theme.vtxSky

/*
 * Easter egg (2 tahap):
 *  1. Ketuk judul "Vertex Launcher" di bilah atas 7 kali dengan cepat -> memberi petunjuk.
 *  2. Ketuk nomor versi di halaman Tentang 5 kali -> hanya berfungsi bila tahap 1 sudah dibuka.
 * Kemajuan disimpan di AllSettings.eggFirst dan AllSettings.eggSecond.
 */

/**
 * Mendeteksi [taps] ketukan beruntun (jeda antar ketukan paling lama [windowMs]).
 * Bila [enabled] = false, ketukan diabaikan sepenuhnya dan tidak ada reaksi apa pun.
 */
fun Modifier.vtxSecretTaps(
    taps: Int,
    enabled: Boolean = true,
    windowMs: Long = 1200L,
    onTriggered: () -> Unit
): Modifier = pointerInput(enabled, taps) {
    if (!enabled) return@pointerInput
    var count = 0
    var last = 0L
    detectTapGestures {
        val now = System.currentTimeMillis()
        count = if (now - last > windowMs) 1 else count + 1
        last = now
        if (count >= taps) {
            count = 0
            onTriggered()
        }
    }
}

@Composable
private fun isIndonesian(): Boolean {
    val language = LocalConfiguration.current.locales[0]?.language
    return language == "in" || language == "id"
}

/** Judul di bilah atas; mengetuknya 7 kali membuka Easter egg pertama */
@Composable
fun VtxEggTitle(
    text: String,
    style: TextStyle,
    softWrap: Boolean,
    maxLines: Int
) {
    var show by remember { mutableStateOf(false) }
    val indonesian = isIndonesian()

    if (show) {
        VtxEasterDialog(
            title = if (indonesian) "Kamu menemukannya" else "You found it",
            message = if (indonesian) {
                "Satu bintang lagi masih bersembunyi.\n\n" +
                    "Ia tinggal di halaman tempat launcher ini memperkenalkan dirinya, " +
                    "di dekat angka yang menandai usianya.\n\n" +
                    "Sentuhlah angka itu lima kali, dan jangan terlalu lambat."
            } else {
                "One more star is still hiding.\n\n" +
                    "It lives on the page where this launcher introduces itself, " +
                    "next to the number that marks its age.\n\n" +
                    "Touch that number five times, and don't be too slow."
            },
            onDismiss = { show = false }
        )
    }

    Text(
        modifier = Modifier.vtxSecretTaps(taps = 7) {
            AllSettings.eggFirst.save(true)
            show = true
        },
        text = text,
        style = style,
        softWrap = softWrap,
        maxLines = maxLines
    )
}

/**
 * Dipakai di halaman Tentang: mengembalikan modifier untuk teks nomor versi.
 * Easter egg kedua HANYA aktif bila yang pertama sudah dibuka; kalau belum,
 * ketukan diabaikan tanpa reaksi apa pun.
 */
@Composable
fun rememberVtxVersionSecret(): Modifier {
    var show by remember { mutableStateOf(false) }
    val indonesian = isIndonesian()

    if (show) {
        VtxEasterDialog(
            title = if (indonesian) "Bintang kedua" else "The second star",
            message = if (indonesian) {
                "Kamu menemukan semuanya.\n\n" +
                    "Terima kasih sudah memakai Vertex Launcher. " +
                    "Semoga langit di layarmu selalu penuh bintang jatuh."
            } else {
                "You found them all.\n\n" +
                    "Thank you for using Vertex Launcher. " +
                    "May the sky on your screen always be full of shooting stars."
            },
            onDismiss = { show = false }
        )
    }

    return Modifier.vtxSecretTaps(
        taps = 5,
        enabled = AllSettings.eggFirst.state
    ) {
        AllSettings.eggSecond.save(true)
        show = true
    }
}

/** Layar penuh bertema langit berbintang; ketuk di mana saja untuk menutup */
@Composable
private fun VtxEasterDialog(
    title: String,
    message: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .vtxSky()
                .pointerInput(Unit) {
                    detectTapGestures { onDismiss() }
                },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 36.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                VtxDiamond(size = 14.dp, color = Vtx.Violet)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = title,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF3ECFF),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = message,
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = Vtx.TextSoft,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "· · ·",
                    fontSize = 14.sp,
                    color = Vtx.Violet.copy(alpha = 0.6f)
                )
            }
        }
    }
}
