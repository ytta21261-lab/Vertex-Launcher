/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.widgets

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.ui.theme.Vtx
import com.movtery.zalithlauncher.ui.theme.VtxDiamond
import com.movtery.zalithlauncher.ui.theme.vtxCardBorder
import kotlin.math.roundToInt

/** Deskripsi satu widget melayang (ukuran dan posisi dalam dp) */
private class VtxWidgetSpec(
    val id: String,
    val enabled: Boolean,
    val readRect: () -> String,
    val writeRect: (String) -> Unit,
    val defaultWidth: Int,
    val defaultHeight: Int,
    val minWidth: Int,
    val minHeight: Int,
    val content: @Composable () -> Unit
)

/**
 * Semua widget yang dinyalakan di Pengaturan, melayang bebas di atas layar utama.
 * Tahan lama di tengah widget lalu seret untuk menggeser ke mana saja di layar.
 * Tahan lama di sudut widget lalu tarik untuk mengubah ukuran.
 */
@Composable
fun VtxFloatingWidgets(containerWidthPx: Float, containerHeightPx: Float) {
    val specs = listOf(
        VtxWidgetSpec(
            id = "clock",
            enabled = AllSettings.widgetClock.state,
            readRect = { AllSettings.widgetClockRect.state },
            writeRect = { AllSettings.widgetClockRect.save(it) },
            defaultWidth = 200, defaultHeight = 90, minWidth = 150, minHeight = 64
        ) { VtxClockContent() },
        VtxWidgetSpec(
            id = "system",
            enabled = AllSettings.widgetSystem.state,
            readRect = { AllSettings.widgetSystemRect.state },
            writeRect = { AllSettings.widgetSystemRect.save(it) },
            defaultWidth = 220, defaultHeight = 110, minWidth = 170, minHeight = 84
        ) { VtxSystemContent() },
        VtxWidgetSpec(
            id = "notes",
            enabled = AllSettings.widgetNotes.state,
            readRect = { AllSettings.widgetNotesRect.state },
            writeRect = { AllSettings.widgetNotesRect.save(it) },
            defaultWidth = 220, defaultHeight = 130, minWidth = 150, minHeight = 80
        ) { VtxNotesContent() },
        VtxWidgetSpec(
            id = "music",
            enabled = AllSettings.widgetMusic.state,
            readRect = { AllSettings.widgetMusicRect.state },
            writeRect = { AllSettings.widgetMusicRect.save(it) },
            defaultWidth = 300, defaultHeight = 380, minWidth = 240, minHeight = 280
        ) { VtxMusicContent() },
        VtxWidgetSpec(
            id = "video",
            enabled = AllSettings.widgetVideo.state,
            readRect = { AllSettings.widgetVideoRect.state },
            writeRect = { AllSettings.widgetVideoRect.save(it) },
            defaultWidth = 280, defaultHeight = 200, minWidth = 200, minHeight = 150
        ) { VtxVideoContent() }
    )

    specs.forEachIndexed { index, spec ->
        if (spec.enabled) {
            key(spec.id) {
                VtxFloatingWidget(spec, index, containerWidthPx, containerHeightPx)
            }
        }
    }
}

@Composable
private fun VtxFloatingWidget(
    spec: VtxWidgetSpec,
    index: Int,
    containerWidthPx: Float,
    containerHeightPx: Float
) {
    val density = LocalDensity.current
    val unit = density.density
    val minWidthPx = spec.minWidth * unit
    val minHeightPx = spec.minHeight * unit

    val state = remember(containerWidthPx, containerHeightPx) {
        val saved = parseRect(spec.readRect())
        val width = (saved?.get(2) ?: spec.defaultWidth) * unit
        val height = (saved?.get(3) ?: spec.defaultHeight) * unit
        // Posisi awal: berundak dari kanan atas supaya tidak menumpuk persis
        val x = if (saved != null) saved[0] * unit else containerWidthPx - width - (20 + index * 24) * unit
        val y = if (saved != null) saved[1] * unit else (16 + index * 44) * unit
        VtxAdjustState(x, y, width, height).also {
            it.clampTo(containerWidthPx, containerHeightPx, minWidthPx, minHeightPx)
        }
    }

    val shape = CutCornerShape(topEnd = 14.dp, bottomStart = 14.dp)
    Box(
        modifier = Modifier
            .offset { IntOffset(state.x.roundToInt(), state.y.roundToInt()) }
            .size(
                width = with(density) { state.w.toDp() },
                height = with(density) { state.h.toDp() }
            )
            .vtxAdjustable(
                state = state,
                containerWidthPx = containerWidthPx,
                containerHeightPx = containerHeightPx,
                minWidthPx = minWidthPx,
                minHeightPx = minHeightPx,
                cornerPx = 36f * unit,
                onCommit = {
                    spec.writeRect(
                        "${(state.x / unit).roundToInt()},${(state.y / unit).roundToInt()}," +
                            "${(state.w / unit).roundToInt()},${(state.h / unit).roundToInt()}"
                    )
                }
            )
            .clip(shape)
            .background(Color(0xFF110D1C).copy(alpha = 0.78f), shape)
            .border(
                if (state.adjusting) BorderStroke(2.dp, Vtx.VioletLight) else vtxCardBorder(),
                shape
            )
    ) {
        spec.content()

        // Penanda sudut saat widget sedang digeser atau diubah ukurannya
        if (state.adjusting) {
            VtxDiamond(size = 10.dp, color = Vtx.VioletLight, modifier = Modifier.align(Alignment.TopStart).padding(4.dp))
            VtxDiamond(size = 10.dp, color = Vtx.VioletLight, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp))
            VtxDiamond(size = 10.dp, color = Vtx.VioletLight, modifier = Modifier.align(Alignment.BottomStart).padding(4.dp))
            VtxDiamond(size = 10.dp, color = Vtx.VioletLight, modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp))
        }
    }
}

/** "x,y,lebar,tinggi" (dp) -> daftar 4 angka, atau null bila belum tersimpan / rusak */
private fun parseRect(text: String): List<Int>? =
    text.split(",").mapNotNull { it.trim().toIntOrNull() }.takeIf { it.size == 4 }
