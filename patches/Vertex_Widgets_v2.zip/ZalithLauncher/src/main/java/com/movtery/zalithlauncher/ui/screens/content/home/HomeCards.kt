/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.screens.content.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.movtery.cardgrid.model.CardLimits
import com.movtery.cardgrid.model.CardType
import com.movtery.zalithlauncher.BuildConfig
import com.movtery.zalithlauncher.BuildKeys
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.ui.components.BackgroundCard
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.setting.unit.BooleanSettingUnit
import com.movtery.zalithlauncher.ui.screens.content.home.server.ServerCardContent
import com.movtery.zalithlauncher.ui.screens.content.home.version.VersionCardContent
import com.movtery.zalithlauncher.ui.widgets.VtxClockContent
import com.movtery.zalithlauncher.ui.widgets.VtxMusicContent
import com.movtery.zalithlauncher.ui.widgets.VtxNotesContent
import com.movtery.zalithlauncher.ui.widgets.VtxSystemContent

/** 系统卡片（不可变更），由启动器自行提供并绘制在网格之外 */
class SystemCard(val id: String, val content: @Composable () -> Unit)

/**
 * 用户卡片图标的圆角
 */
val CardIconShape = RoundedCornerShape(percent = 28)

/**
 * 主页卡片注册表
 */
object HomeCards {
    /** 版本卡片的类型 id */
    const val VERSION_CARD_TYPE_ID = "version_card"

    /** 服务器卡片的类型 id */
    const val SERVER_CARD_TYPE_ID = "server_card"

    private val versionCardType = CardType(
        typeId = VERSION_CARD_TYPE_ID,
        defaultSpan = IntOffset(10, 6),
        limits = CardLimits(
            minWidth = 10,
            minHeight = 4,
            maxHeight = 12
        ),
        content = { cardId ->
            VersionCardContent(cardId)
        }
    )

    /** 服务器卡片类型 */
    private val serverCardType = CardType(
        typeId = SERVER_CARD_TYPE_ID,
        defaultSpan = IntOffset(10, 6),
        limits = CardLimits(
            minWidth = 10,
            minHeight = 4,
            maxHeight = 12
        ),
        content = { cardId ->
            ServerCardContent(cardId)
        }
    )

    /** 版本卡片类型 */
    fun versionCardType(): CardType = versionCardType

    /** 服务器卡片类型 */
    fun serverCardType(): CardType = serverCardType

    /** Id widget (dipakai sebagai id tipe sekaligus id kartu, karena hanya ada satu per jenis) */
    const val WIDGET_CLOCK_ID = "widget_clock"
    const val WIDGET_SYSTEM_ID = "widget_system"
    const val WIDGET_NOTES_ID = "widget_notes"
    const val WIDGET_MUSIC_ID = "widget_music"

    private val widgetClockType = CardType(
        typeId = WIDGET_CLOCK_ID,
        defaultSpan = IntOffset(10, 4),
        limits = CardLimits(minWidth = 6, minHeight = 3, maxHeight = 10),
        content = { _ -> VtxClockContent() }
    )

    private val widgetSystemType = CardType(
        typeId = WIDGET_SYSTEM_ID,
        defaultSpan = IntOffset(10, 5),
        limits = CardLimits(minWidth = 6, minHeight = 3, maxHeight = 10),
        content = { _ -> VtxSystemContent() }
    )

    private val widgetNotesType = CardType(
        typeId = WIDGET_NOTES_ID,
        defaultSpan = IntOffset(10, 6),
        limits = CardLimits(minWidth = 6, minHeight = 3, maxHeight = 14),
        content = { _ -> VtxNotesContent() }
    )

    private val widgetMusicType = CardType(
        typeId = WIDGET_MUSIC_ID,
        defaultSpan = IntOffset(10, 12),
        limits = CardLimits(minWidth = 8, minHeight = 5, maxHeight = 20),
        content = { _ -> VtxMusicContent() }
    )

    /** Jenis kartu widget */
    fun widgetCardTypes(): List<CardType> =
        listOf(widgetClockType, widgetSystemType, widgetNotesType, widgetMusicType)

    /** Sakelar Pengaturan untuk sebuah widget (null bila bukan kartu widget) */
    fun widgetSetting(typeId: String): BooleanSettingUnit? = when (typeId) {
        WIDGET_CLOCK_ID -> AllSettings.widgetClock
        WIDGET_SYSTEM_ID -> AllSettings.widgetSystem
        WIDGET_NOTES_ID -> AllSettings.widgetNotes
        WIDGET_MUSIC_ID -> AllSettings.widgetMusic
        else -> null
    }

    /** 用户卡片类型注册表 */
    val userCardTypes: List<CardType> =
        listOf(versionCardType, serverCardType, widgetClockType, widgetSystemType, widgetNotesType, widgetMusicType)

    /** 系统卡片（不可变更） */
    fun systemCards(): List<SystemCard> = buildList {
        if (BuildConfig.DEBUG) {
            add(debugWarningCard())
        }
    }

    /**
     * debug版本关不掉的警告，防止有人把测试版当正式版用 XD
     */
    private fun debugWarningCard() = SystemCard(id = "system_debug_warning") {
        BackgroundCard(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.extraLarge
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = stringResource(R.string.generic_warning),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = stringResource(R.string.launcher_version_debug_warning, BuildKeys.LAUNCHER_NAME),
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    modifier = Modifier
                        .alpha(0.8f)
                        .align(Alignment.End),
                    text = stringResource(R.string.launcher_version_debug_warning_cant_close),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
