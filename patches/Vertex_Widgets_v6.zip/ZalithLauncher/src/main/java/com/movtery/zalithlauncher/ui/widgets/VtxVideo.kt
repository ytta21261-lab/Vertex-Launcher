/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.ui.widgets

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.TextureView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.ui.theme.Vtx
import kotlinx.coroutines.delay

/** Pemutar video tunggal (ExoPlayer) untuk widget video. */
object VtxVideoPlayer {
    private var player: ExoPlayer? = null

    var isPlaying by mutableStateOf(false)
        private set
    var hasVideo by mutableStateOf(false)
        private set
    var failed by mutableStateOf(false)
        private set
    var aspectRatio by mutableFloatStateOf(16f / 9f)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set

    private fun ensure(context: Context): ExoPlayer {
        player?.let { return it }
        val created = ExoPlayer.Builder(context.applicationContext)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .build()
        created.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                this@VtxVideoPlayer.isPlaying = isPlaying
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    aspectRatio = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    durationMs = created.duration.coerceAtLeast(0L)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                failed = true
                this@VtxVideoPlayer.isPlaying = false
            }
        })
        // Video diulang terus tanpa henti
        created.repeatMode = Player.REPEAT_MODE_ONE
        player = created
        return created
    }

    fun load(context: Context, uri: Uri, autoPlay: Boolean) {
        val exo = ensure(context)
        failed = false
        hasVideo = true
        positionMs = 0L
        durationMs = 0L
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.playWhenReady = autoPlay
    }

    fun attach(context: Context, view: TextureView) {
        ensure(context).setVideoTextureView(view)
    }

    fun detach(view: TextureView) {
        player?.clearVideoTextureView(view)
    }

    fun toggle() {
        player?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun seekToFraction(fraction: Float) {
        val exo = player ?: return
        if (durationMs <= 0L) return
        val target = (durationMs * fraction.coerceIn(0f, 1f)).toLong()
        exo.seekTo(target)
        positionMs = target
    }

    fun refreshPosition() {
        player?.let { positionMs = it.currentPosition.coerceAtLeast(0L) }
    }

    /** Menghentikan video dan membersihkannya (dipanggil saat widget hilang) */
    fun stop() {
        player?.let {
            it.stop()
            it.clearMediaItems()
        }
        isPlaying = false
        hasVideo = false
        failed = false
        positionMs = 0L
        durationMs = 0L
    }
}

/**
 * Isi widget video. Belum ada video: tombol pilih video. Sudah ada video: video diputar
 * berulang tanpa henti, ketuk dua kali pada video untuk memilih video lain.
 */
@Composable
fun VtxVideoContent() {
    val context = LocalContext.current
    val savedUri = AllSettings.widgetVideoUri.state

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            AllSettings.widgetVideoUri.save(uri.toString())
            VtxVideoPlayer.load(context, uri, autoPlay = true)
        }
    }

    // Muat kembali video yang dipilih sebelumnya dan langsung putar
    LaunchedEffect(Unit) {
        if (savedUri.isNotEmpty() && !VtxVideoPlayer.hasVideo) {
            VtxVideoPlayer.load(context, Uri.parse(savedUri), autoPlay = true)
        }
    }
    // Hentikan video saat widget dimatikan atau ditinggalkan
    DisposableEffect(Unit) {
        onDispose { VtxVideoPlayer.stop() }
    }

    val playing = VtxVideoPlayer.isPlaying
    LaunchedEffect(playing) {
        while (playing) {
            VtxVideoPlayer.refreshPosition()
            delay(500L)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        if (VtxVideoPlayer.hasVideo) {
            val ratio = VtxVideoPlayer.aspectRatio
            val boxRatio = maxWidth / maxHeight
            val videoModifier = if (boxRatio > ratio) {
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(ratio)
            } else {
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(ratio)
            }
            AndroidView(
                modifier = videoModifier,
                factory = { ctx ->
                    TextureView(ctx).also { VtxVideoPlayer.attach(ctx, it) }
                },
                onRelease = { VtxVideoPlayer.detach(it) }
            )

            // Lapisan ketuk dua kali: pilih video lain
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = { picker.launch(arrayOf("video/*")) }
                        )
                    }
            )

            if (VtxVideoPlayer.failed) {
                Text(
                    modifier = Modifier.padding(12.dp),
                    text = stringResource(R.string.vx_video_error),
                    fontSize = 12.sp,
                    color = Vtx.TextSoft,
                    textAlign = TextAlign.Center
                )
            }

            // Garis progres tipis di bagian bawah
            VtxSeekBar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                fraction = if (VtxVideoPlayer.durationMs > 0L) {
                    VtxVideoPlayer.positionMs.toFloat() / VtxVideoPlayer.durationMs.toFloat()
                } else 0f,
                onSeek = { VtxVideoPlayer.seekToFraction(it) }
            )
        } else {
            // Belum ada video: tampilkan tombol pilih video
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.vx_video_hint),
                    fontSize = 12.sp,
                    color = Vtx.TextSoft,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(10.dp))
                VtxTab(
                    text = stringResource(R.string.vx_video_pick),
                    selected = true
                ) { picker.launch(arrayOf("video/*")) }
            }
        }
    }
}

/** Bilah progres: ketuk untuk melompat ke posisi tertentu */
@Composable
private fun VtxSeekBar(fraction: Float, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(14.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset -> onSeek(offset.x / size.width) }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0x22FFFFFF))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(Vtx.VioletDeep, Vtx.VioletLight)))
            )
        }
    }
}
